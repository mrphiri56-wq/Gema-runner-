GEMA FULL DESKTOP FUNCTIONAL DEMO

Includes the supplied George Phiri CV in documents/ and exposes it from My Profile.
Open index.html in a desktop browser. This is a simulation, not production.
