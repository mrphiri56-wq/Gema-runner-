GEMA FULL PYTHON TEST v1
========================

REQUIREMENT
Python 3 on Windows. No pip packages are required.

RUN
1. Extract the ZIP.
2. Double-click RUN_GEMA.bat.
3. GEMA opens as a desktop application.
4. A local SQLite database (gema.db) is created automatically.

FULL TEST JOURNEY
Dashboard
-> People & Organisations
-> Business Directory
-> Marketplace
-> Industrial Intelligence
-> Opportunities
-> Investment Projects
-> Investors
-> Investor Matching
-> Deal Workflow
-> Messages
-> Notifications
-> Analytics

GLOBAL SEARCH
Use the search bar in the top-right. It searches businesses, marketplace,
opportunities, projects and investors.

INTERACTIVE FEATURES
- Add parties/businesses/listings/opportunities/projects/investors
- Search across the GEMA data domains
- Run explainable investor matching
- Store matches in SQLite
- Generate notifications from matches
- Send party-to-party messages
- Advance project workflow stages
- View live analytics
- Reset the demo database

IMPORTANT
This is a serious functional DEVELOPMENT TEST BUILD, but it is not the
production GEMA platform. Production work still includes secure authentication,
roles/permissions, encrypted data, cloud database/API, real document/data-room
storage, audit/security controls, real investor onboarding, verification,
payments, external datasets, and deployment.
