import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3, os, datetime, json

BASE=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(BASE,"gema.db")

SCHEMA="""
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, role TEXT, organisation TEXT, email TEXT
);
CREATE TABLE IF NOT EXISTS businesses(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, sector TEXT, location TEXT, description TEXT, owner_id INTEGER, status TEXT
);
CREATE TABLE IF NOT EXISTS marketplace(
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, kind TEXT, sector TEXT, location TEXT, description TEXT, owner_id INTEGER, status TEXT
);
CREATE TABLE IF NOT EXISTS opportunities(
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, sector TEXT, location TEXT, stage TEXT, value TEXT, description TEXT, status TEXT
);
CREATE TABLE IF NOT EXISTS projects(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, sector TEXT, location TEXT, stage TEXT, funding TEXT, description TEXT, owner_id INTEGER
);
CREATE TABLE IF NOT EXISTS investors(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, focus TEXT, geography TEXT, ticket TEXT, capabilities TEXT, status TEXT
);
CREATE TABLE IF NOT EXISTS matches(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, investor_id INTEGER, score INTEGER, factors TEXT, status TEXT
);
CREATE TABLE IF NOT EXISTS workflow(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, stage TEXT, status TEXT, notes TEXT
);
CREATE TABLE IF NOT EXISTS messages(
 id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT, recipient TEXT, subject TEXT, body TEXT, status TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS notifications(
 id INTEGER PRIMARY KEY AUTOINCREMENT, recipient TEXT, message TEXT, read_flag INTEGER DEFAULT 0, created_at TEXT
);
"""

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
    c=db(); c.executescript(SCHEMA)
    if c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]==0:
        c.executemany("INSERT INTO users(name,role,organisation,email) VALUES(?,?,?,?)",[
            ("George Phiri","Platform Administrator","GEMA","admin@gema.local"),
            ("Demo Business Owner","Business","Demo Agro Processing Ltd","business@gema.local"),
            ("Demo Investor","Investor","Demo Industrial Growth Fund","investor@gema.local"),
            ("Demo Government/Agency","Institution","Demo Zambian Industrial Agency","agency@gema.local")])
    if c.execute("SELECT COUNT(*) n FROM businesses").fetchone()["n"]==0:
        c.executemany("INSERT INTO businesses(name,sector,location,description,owner_id,status) VALUES(?,?,?,?,?,?)",[
            ("Demo Agro Processing Ltd","Agriculture & Food Processing","Lusaka","Agro-processing and value addition business",2,"Verified"),
            ("Demo Copper Components Ltd","Mining Supply & Manufacturing","Copperbelt","Manufacturing mining supply components",2,"Demo")])
    if c.execute("SELECT COUNT(*) n FROM marketplace").fetchone()["n"]==0:
        c.executemany("INSERT INTO marketplace(title,kind,sector,location,description,owner_id,status) VALUES(?,?,?,?,?,?,?)",[
            ("Industrial Processing Equipment","Product","Manufacturing","Lusaka","Processing machinery listing",2,"Published"),
            ("Cold Chain Logistics Service","Service","Logistics","Lusaka","Temperature-controlled logistics",2,"Published"),
            ("Copper Value Addition Opportunity","Opportunity","Mining","Copperbelt","Value addition opportunity",4,"Published")])
    if c.execute("SELECT COUNT(*) n FROM opportunities").fetchone()["n"]==0:
        c.executemany("INSERT INTO opportunities(title,sector,location,stage,value,description,status) VALUES(?,?,?,?,?,?,?)",[
            ("Agro-Processing Expansion","Agriculture","Lusaka","Feasibility","USD 2.5M","Expand processing capacity and local value addition","Open"),
            ("Industrial Components Plant","Manufacturing","Copperbelt","Investor Matching","USD 5M","Manufacture industrial components locally","Open"),
            ("Fertilizer Blending Facility","Agriculture","Central","Concept","USD 8M","Local fertilizer blending and distribution","Open")])
    if c.execute("SELECT COUNT(*) n FROM projects").fetchone()["n"]==0:
        c.executemany("INSERT INTO projects(name,sector,location,stage,funding,description,owner_id) VALUES(?,?,?,?,?,?,?)",[
            ("Zambia Agro-Processing Expansion","Agriculture","Lusaka","Feasibility","USD 2.5M","Commercial agro-processing expansion",2),
            ("Industrial Components Plant","Manufacturing","Copperbelt","Investor Matching","USD 5M","Local industrial component manufacturing",2)])
    if c.execute("SELECT COUNT(*) n FROM investors").fetchone()["n"]==0:
        c.executemany("INSERT INTO investors(name,focus,geography,ticket,capabilities,status) VALUES(?,?,?,?,?,?)",[
            ("Demo Industrial Growth Fund","Agriculture; Manufacturing","Zambia; Southern Africa","USD 1M-10M","Industrial growth; project finance","Active"),
            ("Demo Strategic Investor","Mining; Manufacturing","Zambia","USD 2M-20M","Mining supply chains; manufacturing","Active"),
            ("Demo SME Growth Fund","SME; Agriculture","Zambia","USD 100K-3M","SME finance; growth capital","Active")])
    c.commit(); c.close()
init()

class GEMA(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("GEMA — Zambia Open Marketplace & Industrial Intelligence Platform")
        self.geometry("1400x850"); self.minsize(1100,700)
        self.current_user="George Phiri"
        self.search=tk.StringVar()
        self.build()
        self.show("Dashboard")
    def build(self):
        top=tk.Frame(self,bg="#10235b",height=70); top.pack(fill="x")
        tk.Label(top,text="GEMA",font=("Segoe UI",27,"bold"),fg="white",bg="#10235b").pack(side="left",padx=24)
        tk.Label(top,text="Zambia Open Marketplace & Industrial Intelligence Platform",
                 font=("Segoe UI",11),fg="#dbe7ff",bg="#10235b").pack(side="left")
        sf=tk.Frame(top,bg="#10235b");sf.pack(side="right",padx=20)
        e=tk.Entry(sf,textvariable=self.search,width=34,font=("Segoe UI",10))
        e.pack(side="left"); e.bind("<Return>",lambda x:self.global_search())
        ttk.Button(sf,text="Search",command=self.global_search).pack(side="left",padx=5)
        body=tk.Frame(self);body.pack(fill="both",expand=True)
        self.nav=tk.Frame(body,bg="#0b1738",width=245);self.nav.pack(side="left",fill="y")
        self.main=tk.Frame(body,bg="#f5f7fb");self.main.pack(side="right",fill="both",expand=True)
        sections=[
          ("Dashboard","Dashboard"),("People & Organisations","People"),("Business Directory","Businesses"),
          ("Marketplace","Marketplace"),("Industrial Intelligence","Industrial"),("Opportunities","Opportunities"),
          ("Investment Projects","Projects"),("Investors","Investors"),("Investor Matching","Matching"),
          ("Deal Workflow","Workflow"),("Messages","Messages"),("Notifications","Notifications"),
          ("Analytics","Analytics"),("Administration","Admin")]
        for text,key in sections:
            tk.Button(self.nav,text=text,command=lambda k=key:self.show(k),anchor="w",
                      bg="#0b1738",fg="#e4edff",activebackground="#1e3a8a",activeforeground="white",
                      relief="flat",padx=18,pady=10,font=("Segoe UI",10)).pack(fill="x")
        tk.Label(self.nav,text="\nGEMA FULL PYTHON TEST\nSQLite local database\nInteractive workflow",bg="#0b1738",
                 fg="#8fa4cf",justify="left",font=("Segoe UI",9)).pack(anchor="w",padx=18,pady=22)
    def clear(self):
        for w in self.main.winfo_children(): w.destroy()
    def head(self,title,sub=""):
        tk.Label(self.main,text=title,font=("Segoe UI",25,"bold"),bg="#f5f7fb").pack(anchor="w",padx=28,pady=(25,2))
        if sub: tk.Label(self.main,text=sub,fg="#64748b",bg="#f5f7fb").pack(anchor="w",padx=28,pady=(0,18))
    def query(self,sql,args=()):
        c=db();r=c.execute(sql,args).fetchall();c.close();return r
    def exec(self,sql,args=()):
        c=db();c.execute(sql,args);c.commit();c.close()
    def show(self,key):
        getattr(self,"page_"+key.lower())()
    def page_dashboard(self):
        self.clear();self.head("GEMA Dashboard","Full Python test build — connected local SQLite database")
        vals=[("Users","users"),("Businesses","businesses"),("Marketplace","marketplace"),("Opportunities","opportunities"),
              ("Projects","projects"),("Investors","investors"),("Matches","matches"),("Messages","messages")]
        row=tk.Frame(self.main,bg="#f5f7fb");row.pack(fill="x",padx=20)
        for lab,t in vals:
            f=tk.Frame(row,bg="white",highlightbackground="#dbe3ef",highlightthickness=1);f.pack(side="left",fill="both",expand=True,padx=5)
            n=self.query(f"SELECT COUNT(*) n FROM {t}")[0]["n"]
            tk.Label(f,text=lab,fg="#64748b",bg="white").pack(anchor="w",padx=12,pady=(12,2))
            tk.Label(f,text=n,font=("Segoe UI",18,"bold"),bg="white").pack(anchor="w",padx=12,pady=(0,12))
        p=tk.Frame(self.main,bg="white",highlightbackground="#dbe3ef",highlightthickness=1);p.pack(fill="both",expand=True,padx=28,pady=20)
        tk.Label(p,text="Operational journey",font=("Segoe UI",15,"bold"),bg="white").pack(anchor="w",padx=20,pady=15)
        for x in ["User/organisation profile → Business profile","Search → Marketplace → Industrial opportunities",
                  "Opportunity → Investment Project → Investor Matching","Match → Due Diligence → Data Room → Term Sheet",
                  "Messages → Notifications → Monitoring → Analytics"]:
            tk.Label(p,text="  • "+x,bg="white",font=("Segoe UI",11)).pack(anchor="w",padx=25,pady=5)
    def treepage(self,title,sub,table,cols,rows,buttons=None):
        self.clear();self.head(title,sub)
        if buttons:
            bar=tk.Frame(self.main,bg="#f5f7fb");bar.pack(fill="x",padx=28)
            for txt,cmd in buttons:ttk.Button(bar,text=txt,command=cmd).pack(side="left",padx=(0,7))
        tr=ttk.Treeview(self.main,columns=cols,show="headings")
        for c in cols:tr.heading(c,text=c.title());tr.column(c,width=max(120,1100//len(cols)))
        tr.pack(fill="both",expand=True,padx=28,pady=18)
        for r in rows:tr.insert("", "end",values=tuple(r[c] for c in cols))
        return tr
    def page_people(self):
        rows=self.query("SELECT * FROM users ORDER BY id DESC")
        self.treepage("People & Organisations","Parties participating in GEMA", "users",
                      ["name","role","organisation","email"],rows,
                      [("Add Party",self.add_party)])
    def add_party(self):
        w=self.form("Add Party",[("Name",""),("Role","Business / Investor / Institution / User"),("Organisation",""),("Email","")])
        def go(es):
            self.exec("INSERT INTO users(name,role,organisation,email) VALUES(?,?,?,?)",[e.get() for e in es]);w.destroy();self.page_people()
        ttk.Button(w,text="Save",command=lambda:go(es)).pack(pady=18)
    def form(self,title,fields):
        w=tk.Toplevel(self);w.title(title);w.geometry("520x450");es=[]
        for lab,ph in fields:
            tk.Label(w,text=lab).pack(anchor="w",padx=20,pady=(13,2));e=tk.Entry(w);e.pack(fill="x",padx=20);es.append(e)
        return w
    def page_businesses(self):
        rows=self.query("SELECT * FROM businesses ORDER BY id DESC")
        self.treepage("Business Directory","Business profiles and capabilities", "businesses",
                      ["name","sector","location","status"],rows,[("Register Business",self.add_business)])
    def add_business(self):
        w=self.form("Register Business",[("Business name",""),("Sector",""),("Location",""),("Description","")])
        def go(es):
            self.exec("INSERT INTO businesses(name,sector,location,description,owner_id,status) VALUES(?,?,?,?,?,?)",
                      [es[0].get(),es[1].get(),es[2].get(),es[3].get(),1,"User-created"]);w.destroy();self.page_businesses()
        ttk.Button(w,text="Save Business",command=lambda:go(es)).pack(pady=18)
    def page_marketplace(self):
        rows=self.query("SELECT * FROM marketplace ORDER BY id DESC")
        self.treepage("Marketplace","Products, services and opportunities", "marketplace",
                      ["title","kind","sector","location","status"],rows,[("Publish Listing",self.add_listing)])
    def add_listing(self):
        w=self.form("Publish Marketplace Listing",[("Title",""),("Type","Product / Service / Opportunity"),("Sector",""),("Location",""),("Description","")])
        def go(es):
            self.exec("INSERT INTO marketplace(title,kind,sector,location,description,owner_id,status) VALUES(?,?,?,?,?,?,?)",
                      [es[0].get(),es[1].get(),es[2].get(),es[3].get(),es[4].get(),1,"Published"]);w.destroy();self.page_marketplace()
        ttk.Button(w,text="Publish",command=lambda:go(es)).pack(pady=18)
    def page_industrial(self):
        self.clear();self.head("Industrial Intelligence","Sector intelligence, value addition and industrial opportunity discovery")
        for s in ["Agriculture & Food Processing","Mining & Mineral Value Addition","Manufacturing","Energy & Utilities","Logistics & Infrastructure","ICT & Digital Services"]:
            f=tk.Frame(self.main,bg="white",highlightbackground="#dbe3ef",highlightthickness=1);f.pack(fill="x",padx=28,pady=5)
            tk.Label(f,text=s,font=("Segoe UI",12,"bold"),bg="white").pack(side="left",padx=15,pady=14)
            ttk.Button(f,text="Explore",command=lambda z=s:self.explore_sector(z)).pack(side="right",padx=15)
    def explore_sector(self,s):
        rows=self.query("SELECT * FROM opportunities WHERE sector LIKE ?",("%"+s.split(" & ")[0]+"%",))
        messagebox.showinfo("Industrial Intelligence",f"{s}\n\n{len(rows)} matching opportunity records found in the local database.")
    def page_opportunities(self):
        rows=self.query("SELECT * FROM opportunities ORDER BY id DESC")
        self.treepage("Industrial Opportunities","Open opportunities from the GEMA opportunity layer","opportunities",
                      ["title","sector","location","stage","value","status"],rows,[("Add Opportunity",self.add_opportunity)])
    def add_opportunity(self):
        w=self.form("Add Opportunity",[("Title",""),("Sector",""),("Location",""),("Stage",""),("Value",""),("Description","")])
        def go(es):
            self.exec("INSERT INTO opportunities(title,sector,location,stage,value,description,status) VALUES(?,?,?,?,?,?,?)",
                      [x.get() for x in es]+["Open"]);w.destroy();self.page_opportunities()
        ttk.Button(w,text="Save Opportunity",command=lambda:go(es)).pack(pady=18)
    def page_projects(self):
        rows=self.query("SELECT * FROM projects ORDER BY id DESC")
        self.treepage("Investment Projects","Feasibility, pipeline and funding requirements","projects",
                      ["name","sector","location","stage","funding"],rows,[("Create Project",self.add_project)])
    def add_project(self):
        w=self.form("Create Investment Project",[("Project name",""),("Sector",""),("Location",""),("Stage",""),("Funding",""),("Description","")])
        def go(es):
            self.exec("INSERT INTO projects(name,sector,location,stage,funding,description,owner_id) VALUES(?,?,?,?,?,?,?)",
                      [x.get() for x in es]+[1]);w.destroy();self.page_projects()
        ttk.Button(w,text="Create",command=lambda:go(es)).pack(pady=18)
    def page_investors(self):
        rows=self.query("SELECT * FROM investors ORDER BY id DESC")
        self.treepage("Investors","Investor profiles and investment capabilities","investors",
                      ["name","focus","geography","ticket","status"],rows,[("Add Investor",self.add_investor)])
    def add_investor(self):
        w=self.form("Add Investor",[("Name",""),("Focus sectors",""),("Geography",""),("Ticket range",""),("Capabilities","")])
        def go(es):
            self.exec("INSERT INTO investors(name,focus,geography,ticket,capabilities,status) VALUES(?,?,?,?,?,?)",
                      [x.get() for x in es]+["Active"]);w.destroy();self.page_investors()
        ttk.Button(w,text="Save Investor",command=lambda:go(es)).pack(pady=18)
    def page_matching(self):
        self.clear();self.head("Investor Matching","Run an explainable match and store the result")
        projects=self.query("SELECT id,name,sector FROM projects")
        investors=self.query("SELECT id,name,focus FROM investors")
        tk.Label(self.main,text="Project",bg="#f5f7fb").pack(anchor="w",padx=28);pc=ttk.Combobox(self.main,state="readonly",width=70,
            values=[f"{p['id']} — {p['name']}" for p in projects]);pc.pack(anchor="w",padx=28,pady=5)
        tk.Label(self.main,text="Investor",bg="#f5f7fb").pack(anchor="w",padx=28);ic=ttk.Combobox(self.main,state="readonly",width=70,
            values=[f"{i['id']} — {i['name']}" for i in investors]);ic.pack(anchor="w",padx=28,pady=5)
        out=tk.Text(self.main,height=18);out.pack(fill="both",expand=True,padx=28,pady=15)
        def run():
            if not pc.get() or not ic.get():return
            pid=int(pc.get().split(" — ")[0]);iid=int(ic.get().split(" — ")[0])
            p=self.query("SELECT * FROM projects WHERE id=?",(pid,))[0];inv=self.query("SELECT * FROM investors WHERE id=?",(iid,))[0]
            sector=20 if any(x.strip().lower() in inv["focus"].lower() for x in p["sector"].split(",")) or p["sector"].lower() in inv["focus"].lower() else 8
            geo=20 if "zambia" in inv["geography"].lower() else 10
            score=min(98,sector+geo+25+20+10)
            factors=["Sector alignment" if sector==20 else "Partial sector alignment","Geography alignment" if geo==20 else "Regional geography",
                     "Funding/ticket compatibility (demo signal)","Industrial capability fit (demo signal)","Profile completeness"]
            self.exec("INSERT INTO matches(project_id,investor_id,score,factors,status) VALUES(?,?,?,?,?)",(pid,iid,score,json.dumps(factors),"Suggested"))
            self.exec("INSERT INTO notifications(recipient,message,created_at) VALUES(?,?,datetime('now'))",(inv["name"],f"New GEMA project match suggestion: {p['name']}"))
            out.delete("1.0","end");out.insert("end",json.dumps({"project":p["name"],"investor":inv["name"],"score":score,"factors":factors},indent=2))
        ttk.Button(self.main,text="Run Explainable Match",command=run).pack(anchor="w",padx=28)
    def page_workflow(self):
        self.clear();self.head("Deal Workflow","Move a selected project through the investment lifecycle")
        ps=self.query("SELECT id,name FROM projects");pc=ttk.Combobox(self.main,state="readonly",width=70,values=[f"{p['id']} — {p['name']}" for p in ps]);pc.pack(anchor="w",padx=28)
        stages=["Due Diligence","Secure Data Room","Term Sheet & Negotiation","Closing Readiness","Monitoring"]
        for s in stages:
            f=tk.Frame(self.main,bg="white",highlightbackground="#dbe3ef",highlightthickness=1);f.pack(fill="x",padx=28,pady=5)
            tk.Label(f,text=s,font=("Segoe UI",11,"bold"),bg="white").pack(side="left",padx=15,pady=12)
            ttk.Button(f,text="Advance / Open",command=lambda z=s:self.advance_workflow(pc,z)).pack(side="right",padx=15)
    def advance_workflow(self,pc,stage):
        if not pc.get():messagebox.showwarning("GEMA","Select a project first.");return
        pid=int(pc.get().split(" — ")[0]);self.exec("INSERT INTO workflow(project_id,stage,status,notes) VALUES(?,?,?,?)",(pid,stage,"Active","Test workflow event"))
        self.exec("INSERT INTO notifications(recipient,message,created_at) VALUES(?,?,datetime('now'))",("George Phiri",f"Workflow advanced: {stage}"))
        messagebox.showinfo("GEMA Workflow",f"{stage} recorded for the selected project.")
    def page_messages(self):
        rows=self.query("SELECT * FROM messages ORDER BY id DESC")
        self.treepage("Messages","Party-to-party communication test","messages",
                      ["sender","recipient","subject","status","created_at"],rows,[("New Message",self.new_message)])
    def new_message(self):
        w=self.form("New GEMA Message",[("Recipient",""),("Subject",""),("Message","")])
        def go(es):
            self.exec("INSERT INTO messages(sender,recipient,subject,body,status,created_at) VALUES(?,?,?,?,?,datetime('now'))",
                      ("George Phiri",es[0].get(),es[1].get(),es[2].get(),"Sent"))
            self.exec("INSERT INTO notifications(recipient,message,created_at) VALUES(?,?,datetime('now'))",(es[0].get(),f"New message: {es[1].get()}"))
            w.destroy();self.page_messages()
        ttk.Button(w,text="Send",command=lambda:go(es)).pack(pady=18)
    def page_notifications(self):
        rows=self.query("SELECT * FROM notifications ORDER BY id DESC")
        self.treepage("Notifications","System and party workflow notifications","notifications",
                      ["recipient","message","read_flag","created_at"],rows,[("Mark All Read",self.read_all)])
    def read_all(self):
        self.exec("UPDATE notifications SET read_flag=1");self.page_notifications()
    def page_analytics(self):
        self.clear();self.head("Analytics","Live counts from the GEMA SQLite database")
        for t in ["users","businesses","marketplace","opportunities","projects","investors","matches","workflow","messages","notifications"]:
            n=self.query(f"SELECT COUNT(*) n FROM {t}")[0]["n"]
            tk.Label(self.main,text=f"{t.title()}: {n}",font=("Segoe UI",12),bg="#f5f7fb").pack(anchor="w",padx=45,pady=4)
    def page_admin(self):
        self.clear();self.head("Administration","Local development controls")
        ttk.Button(self.main,text="Reset Test Database",command=self.reset_db).pack(anchor="w",padx=28,pady=10)
        tk.Label(self.main,text="Database file: gema.db\nThis is a development build. Production authentication, encryption, cloud hosting, audit controls and real integrations still need to be implemented.",
                 bg="#f5f7fb",fg="#64748b",justify="left").pack(anchor="w",padx=28,pady=20)
    def reset_db(self):
        if messagebox.askyesno("Reset","Delete local test data and restore the seeded GEMA demo?"):
            self.destroy()
            os.remove(DB) if os.path.exists(DB) else None
            init();GEMA().mainloop()
    def global_search(self):
        q=self.search.get().strip()
        self.clear();self.head("Global Search",f"Results for: {q or 'all'}")
        if not q:q="%"
        else:q="%"+q+"%"
        groups=[
          ("Businesses","SELECT name,sector,location FROM businesses WHERE name LIKE ? OR sector LIKE ? OR location LIKE ?",[q,q,q]),
          ("Marketplace","SELECT title,kind,location FROM marketplace WHERE title LIKE ? OR sector LIKE ? OR location LIKE ?",[q,q,q]),
          ("Opportunities","SELECT title,sector,location FROM opportunities WHERE title LIKE ? OR sector LIKE ? OR location LIKE ?",[q,q,q]),
          ("Projects","SELECT name,sector,location FROM projects WHERE name LIKE ? OR sector LIKE ? OR location LIKE ?",[q,q,q]),
          ("Investors","SELECT name,focus,geography FROM investors WHERE name LIKE ? OR focus LIKE ? OR geography LIKE ?",[q,q,q])]
        found=0
        for name,sql,args in groups:
            rs=self.query(sql,args)
            if rs:
                found+=len(rs);tk.Label(self.main,text=name,font=("Segoe UI",14,"bold"),bg="#f5f7fb").pack(anchor="w",padx=28,pady=(12,4))
                for r in rs:tk.Label(self.main,text=" • "+" | ".join(str(v) for v in r),bg="#f5f7fb",font=("Segoe UI",10)).pack(anchor="w",padx=42,pady=2)
        if not found:tk.Label(self.main,text="No results found.",bg="#f5f7fb",fg="#64748b").pack(anchor="w",padx=28,pady=20)

if __name__=="__main__":
    GEMA().mainloop()
