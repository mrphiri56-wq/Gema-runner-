package com.gema.platform

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.content.res.Configuration

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private lateinit var title: TextView

    private val modules = listOf(
        "Dashboard","Business Directory","Marketplace","Industrial Intelligence",
        "Investment Projects","Investor Matching","Due Diligence","Data Room",
        "Project Pipeline","Analytics","Administration"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildShell()
        showDashboard()
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(238,242,246))
        }

        val header = TextView(this).apply {
            text = "  GEMA   |   Zambia Open Marketplace & Industrial Intelligence Platform"
            textSize = 20f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(16,35,63))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20,0,10,0)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 72))

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8,16,8,8)
            setBackgroundColor(Color.rgb(23,43,73))
        }
        val navWidth = if (resources.configuration.screenWidthDp >= 900) 270 else 220
        body.addView(nav, LinearLayout.LayoutParams(navWidth, -1))

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28,24,28,24)
        }
        body.addView(content, LinearLayout.LayoutParams(0,-1,1f))

        modules.forEach { module ->
            val b = Button(this).apply {
                text = module
                textSize = 13f
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { showModule(module) }
            }
            nav.addView(b, LinearLayout.LayoutParams(-1, 52))
        }

        root.addView(body, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun basePage(name:String, description:String) {
        content.removeAllViews()
        title = TextView(this).apply {
            text = name
            textSize = 28f
            setTextColor(Color.rgb(23,43,73))
        }
        content.addView(title, LinearLayout.LayoutParams(-1,60))
        content.addView(TextView(this).apply {
            text = description
            textSize = 15f
            setTextColor(Color.DKGRAY)
        }, LinearLayout.LayoutParams(-1,70))
    }

    private fun showDashboard() {
        basePage("GEMA Command Dashboard",
            "Desktop-style tablet workspace for the integrated GEMA platform.")
        val grid = GridLayout(this).apply { columnCount = 3 }
        val cards = listOf(
            "BUSINESSES" to "1,000+","OPPORTUNITIES" to "MVP Intelligence",
            "INVESTMENT" to "Project Pipeline","INVESTORS" to "Matching Engine",
            "DUE DILIGENCE" to "Verification","SYSTEM" to "Desktop Online"
        )
        cards.forEach { (a,b) ->
            val card = LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL
                setPadding(22,18,22,18)
                setBackgroundColor(Color.WHITE)
            }
            card.addView(TextView(this).apply { text=a; textSize=12f; setTextColor(Color.DKGRAY) })
            card.addView(TextView(this).apply { text=b; textSize=19f; setTextColor(Color.rgb(16,35,63)) })
            val lp=GridLayout.LayoutParams().apply {
                width=0; height=135; columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)
                setMargins(8,8,8,8)
            }
            grid.addView(card,lp)
        }
        content.addView(grid, LinearLayout.LayoutParams(-1,300))
        val info=TextView(this).apply {
            text="\nGEMA is designed as a national industrial intelligence and marketplace workspace. " +
                 "On tablets, the persistent left navigation and multi-column dashboard provide a desktop-like experience."
            textSize=15f; setTextColor(Color.DKGRAY); setPadding(10,20,10,10)
        }
        content.addView(info)
    }

    private fun showModule(name:String) {
        basePage(name, "GEMA workspace — desktop tablet layout")
        val box=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE); setPadding(24,20,24,20)
        }
        box.addView(TextView(this).apply {
            text="Workspace functions"; textSize=19f; setTextColor(Color.rgb(23,43,73))
        })
        listOf("View records","Search and filter","Create / submit","Review and verify","Reports and analytics")
            .forEach {
                box.addView(Button(this).apply {
                    text=it; gravity=Gravity.START; setOnClickListener {
                        Toast.makeText(this@MainActivity, "$it — $name", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        content.addView(box, LinearLayout.LayoutParams(-1,-1))
    }
}
