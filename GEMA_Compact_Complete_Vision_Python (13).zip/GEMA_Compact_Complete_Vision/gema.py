import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3, os, datetime, json

BASE=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(BASE,"gema.db")

SCHEMA="""
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, role TEXT, organisation TEXT, email TEXT
);
CREATE TABLE IF NOT EXISTS businesses(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, sector TEXT, location TEXT, description TEXT, owner_id INTEGER, status TEXT
);
CREATE TABLE IF NOT EXISTS marketplace(
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, kind TEXT, sector TEXT, location TEXT, description TEXT, owner_id INTEGER, status TEXT
);
CREATE TABLE IF NOT EXISTS opportunities(
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, sector TEXT, location TEXT, stage TEXT, value TEXT, description TEXT, status TEXT
);
CREATE TABLE IF NOT EXISTS projects(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, sector TEXT, location TEXT, stage TEXT, funding TEXT, description TEXT, owner_id INTEGER
);
CREATE TABLE IF NOT EXISTS investors(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, focus TEXT, geography TEXT, ticket TEXT, capabilities TEXT, status TEXT
);
CREATE TABLE IF NOT EXISTS matches(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, investor_id INTEGER, score INTEGER, factors TEXT, status TEXT
);
CREATE TABLE IF NOT EXISTS workflow(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, stage TEXT, status TEXT, notes TEXT
);
CREATE TABLE IF NOT EXISTS messages(
 id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT, recipient TEXT, subject TEXT, body TEXT, status TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS notifications(
 id INTEGER PRIMARY KEY AUTOINCREMENT, recipient TEXT, message TEXT, read_flag INTEGER DEFAULT 0, created_at TEXT
);
"""

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
    c=db(); c.executescript(SCHEMA)
    if c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]==0:
        c.executemany("INSERT INTO users(name,role,organisation,email) VALUES(?,?,?,?)",[
            ("George Phiri","Platform Administrator","GEMA","admin@gema.local"),
            ("Demo Business Owner","Business","Demo Agro Processing Ltd","business@gema.local"),
            ("Demo Investor","Investor","Demo Industrial Growth Fund","investor@gema.local"),
            ("Demo Government/Agency","Institution","Demo Zambian Industrial Agency","agency@gema.local")])
    if c.execute("SELECT COUNT(*) n FROM businesses").fetchone()["n"]==0:
        c.executemany("INSERT INTO businesses(name,sector,location,description,owner_id,status) VALUES(?,?,?,?,?,?)",[
            ("Demo Agro Processing Ltd","Agriculture & Food Processing","Lusaka","Agro-processing and value addition business",2,"Verified"),
            ("Demo Copper Components Ltd","Mining Supply & Manufacturing","Copperbelt","Manufacturing mining supply components",2,"Demo")])
    if c.execute("SELECT COUNT(*) n FROM marketplace").fetchone()["n"]==0:
        c.executemany("INSERT INTO marketplace(title,kind,sector,location,description,owner_id,status) VALUES(?,?,?,?,?,?,?)",[
            ("Industrial Processing Equipment","Product","Manufacturing","Lusaka","Processing machinery listing",2,"Published"),
            ("Cold Chain Logistics Service","Service","Logistics","Lusaka","Temperature-controlled logistics",2,"Published"),
            ("Copper Value Addition Opportunity","Opportunity","Mining","Copperbelt","Value addition opportunity",4,"Published")])
    if c.execute("SELECT COUNT(*) n FROM opportunities").fetchone()["n"]==0:
        c.executemany("INSERT INTO opportunities(title,sector,location,stage,value,description,status) VALUES(?,?,?,?,?,?,?)",[
            ("Agro-Processing Expansion","Agriculture","Lusaka","Feasibility","USD 2.5M","Expand processing capacity and local value addition","Open"),
            ("Industrial Components Plant","Manufacturing","Copperbelt","Investor Matching","USD 5M","Manufacture industrial components locally","Open"),
            ("Fertilizer Blending Facility","Agriculture","Central","Concept","USD 8M","Local fertilizer blending and distribution","Open")])
    if c.execute("SELECT COUNT(*) n FROM projects").fetchone()["n"]==0:
        c.executemany("INSERT INTO projects(name,sector,location,stage,funding,description,owner_id) VALUES(?,?,?,?,?,?,?)",[
            ("Zambia Agro-Processing Expansion","Agriculture","Lusaka","Feasibility","USD 2.5M","Commercial agro-processing expansion",2),
            ("Industrial Components Plant","Manufacturing","Copperbelt","Investor Matching","USD 5M","Local industrial component manufacturing",2)])
    if c.execute("SELECT COUNT(*) n FROM investors").fetchone()["n"]==0:
        c.executemany("INSERT INTO investors(name,focus,geography,ticket,capabilities,status) VALUES(?,?,?,?,?,?)",[
            ("Demo Industrial Growth Fund","Agriculture; Manufacturing","Zambia; Southern Africa","USD 1M-10M","Industrial growth; project finance","Active"),
            ("Demo Strategic Investor","Mining; Manufacturing","Zambia","USD 2M-20M","Mining supply chains; manufacturing","Active"),
            ("Demo SME Growth Fund","SME; Agriculture","Zambia","USD 100K-3M","SME finance; growth capital","Active")])
    c.commit(); c.close()
init()

class GEMA(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("GEMA — Zambia Open Marketplace & Industrial Intelligence Platform")
        self.geometry("1500x900"); self.minsize(1180,760)
        self.current_user="George Phiri"
        self.search=tk.StringVar()
        self.build()
        self.show("Dashboard")
    def build(self):
        top=tk.Frame(self,bg="#ffffff",height=68,highlightbackground="#dbe3ef",highlightthickness=1); top.pack(fill="x")
        tk.Label(top,text="GEMA",font=("Segoe UI",26,"bold"),fg="#10212b",bg="#ffffff").pack(side="left",padx=(22,10))
        tk.Label(top,text="ZAMBIA OPEN MARKETPLACE & INDUSTRIAL INTELLIGENCE PLATFORM",font=("Segoe UI",9,"bold"),fg="#36505b",bg="#ffffff").pack(side="left")
        sf=tk.Frame(top,bg="#ffffff"); sf.pack(side="left",fill="x",expand=True,padx=55)
        e=tk.Entry(sf,textvariable=self.search,width=52,font=("Segoe UI",10),relief="solid",bd=1); e.pack(side="left",fill="x",expand=True,ipady=7); e.bind("<Return>",lambda x:self.global_search())
        ttk.Button(sf,text="🔎",command=self.global_search).pack(side="left",padx=(5,0),ipady=3)
        tk.Label(top,text="●",fg="#16a34a",bg="#ffffff",font=("Segoe UI",14)).pack(side="right",padx=(8,3))
        tk.Label(top,text="George Phiri",font=("Segoe UI",10,"bold"),fg="#20313b",bg="#ffffff").pack(side="right",padx=(4,20))

        body=tk.Frame(self); body.pack(fill="both",expand=True)
        self.nav=tk.Frame(body,bg="#063b2b",width=220); self.nav.pack(side="left",fill="y"); self.nav.pack_propagate(False)
        self.main=tk.Frame(body,bg="#f3f7f5"); self.main.pack(side="right",fill="both",expand=True)
        sections=[
          ("⌂  Dashboard","Dashboard"),("♙  My Profile","Profile"),("▥  People & Organisations","People"),
          ("▦  Business Directory","Businesses"),("🛒  Marketplace","Marketplace"),("⌁  Industrial Intelligence","Industrial"),
          ("💡  Opportunities","Opportunities"),("▤  Investment Projects","Projects"),("♧  Investors","Investors"),
          ("◎  Investor Matching","Matching"),("⟐  Deal Workflow","Workflow"),("✓  Due Diligence","DueDiligence"),
          ("▱  Data Room","DataRoom"),("✉  Messages","Messages"),("♧  Notifications","Notifications"),
          ("▥  Analytics","Analytics"),("⚙  Administration","Admin")]
        for text,key in sections:
            tk.Button(self.nav,text=text,command=lambda k=key:self.show(k),anchor="w",bg="#063b2b",fg="#e8f5ef",activebackground="#08784e",activeforeground="white",relief="flat",padx=16,pady=8,font=("Segoe UI",9)).pack(fill="x")
        tk.Frame(self.nav,bg="#08784e",height=1).pack(fill="x",padx=14,pady=(18,8))
        tk.Label(self.nav,text="🇿🇲  Zambia",bg="#063b2b",fg="white",font=("Segoe UI",10,"bold")).pack(anchor="w",padx=16)
        tk.Label(self.nav,text="Connect  •  Match  •  Invest  •  Grow",bg="#063b2b",fg="#a8d7c2",font=("Segoe UI",8)).pack(anchor="w",padx=16,pady=8)
        tk.Label(self.nav,text="SYSTEM ONLINE  •  GEMA v1.0",bg="#063b2b",fg="#77d9a9",font=("Segoe UI",8)).pack(side="bottom",anchor="w",padx=16,pady=14)
    def clear(self):
        for w in self.main.winfo_children(): w.destroy()
    def head(self,title,sub=""):
        tk.Label(self.main,text=title,font=("Segoe UI",25,"bold"),bg="#f5f7fb").pack(anchor="w",padx=28,pady=(25,2))
        if sub: tk.Label(self.main,text=sub,fg="#64748b",bg="#f5f7fb").pack(anchor="w",padx=28,pady=(0,18))
    def query(self,sql,args=()):
        c=db();r=c.execute(sql,args).fetchall();c.close();return r
    def exec(self,sql,args=()):
        c=db();c.execute(sql,args);c.commit();c.close()
    def show(self,key):
        getattr(self,"page_"+key.lower())()
    def page_dashboard(self):
        self.clear()
        # Branded compact hero banner using the supplied GEMA visual direction.
        try:
            self.banner_img=tk.PhotoImage(file=os.path.join(BASE,"gema_banner.png"))
            tk.Label(self.main,image=self.banner_img,bg="#f3f7f5").pack(fill="x",padx=12,pady=(10,6))
        except Exception:
            tk.Label(self.main,text="GEMA — Zambia Open Marketplace & Industrial Intelligence Platform",font=("Segoe UI",20,"bold"),bg="#e7f3ee",fg="#063b2b").pack(fill="x",padx=12,pady=10)

        content=tk.Frame(self.main,bg="#f3f7f5"); content.pack(fill="both",expand=True,padx=12,pady=4)
        for col in range(4): content.grid_columnconfigure(col,weight=1)
        content.grid_rowconfigure(3,weight=1)
        cards=[("Registered Businesses","1,248","+12%"),("Active Opportunities","86","+18%"),("Investment Projects","52","+9%"),("Matching Opportunities","142","+24%")]
        for i,(lab,val,chg) in enumerate(cards):
            f=tk.Frame(content,bg="white",highlightbackground="#d8e5df",highlightthickness=1); f.grid(row=0,column=i,sticky="nsew",padx=4,pady=4)
            tk.Label(f,text=lab,bg="white",fg="#52666e",font=("Segoe UI",9,"bold")).pack(anchor="w",padx=12,pady=(10,2))
            tk.Label(f,text=val,bg="white",fg="#0c4b37",font=("Segoe UI",19,"bold")).pack(anchor="w",padx=12)
            tk.Label(f,text=f"▲ {chg} vs last month",bg="white",fg="#16a34a",font=("Segoe UI",8)).pack(anchor="w",padx=12,pady=(0,9))

        searchf=tk.Frame(content,bg="white",highlightbackground="#d8e5df",highlightthickness=1); searchf.grid(row=1,column=0,columnspan=4,sticky="ew",padx=4,pady=4)
        tk.Label(searchf,text="Global Search",bg="white",fg="#20313b",font=("Segoe UI",11,"bold")).pack(anchor="w",padx=12,pady=(8,3))
        se=tk.Entry(searchf,textvariable=self.search,font=("Segoe UI",10),relief="solid",bd=1); se.pack(side="left",fill="x",expand=True,padx=(12,5),pady=(0,8),ipady=6); se.bind("<Return>",lambda x:self.global_search())
        ttk.Button(searchf,text="Search",command=self.global_search).pack(side="left",padx=(0,12),pady=(0,8),ipady=3)

        actions=[("Business Directory",self.page_businesses),("Marketplace",self.page_marketplace),("Industrial Intelligence",self.page_industrial),("Opportunities",self.page_opportunities),("Investment Projects",self.page_projects),("Investor Matching",self.page_matching)]
        af=tk.Frame(content,bg="#f3f7f5"); af.grid(row=2,column=0,columnspan=4,sticky="ew",padx=0,pady=2)
        for i,(lab,cmd) in enumerate(actions):
            b=tk.Button(af,text=lab,command=cmd,bg="white",fg="#164e3b",activebackground="#e7f5ee",relief="solid",bd=1,font=("Segoe UI",8,"bold"),padx=9,pady=7); b.pack(side="left",fill="x",expand=True,padx=3)

        left=tk.Frame(content,bg="white",highlightbackground="#d8e5df",highlightthickness=1); left.grid(row=3,column=0,columnspan=2,sticky="nsew",padx=4,pady=4)
        tk.Label(left,text="Recent Activity",bg="white",fg="#20313b",font=("Segoe UI",11,"bold")).pack(anchor="w",padx=12,pady=8)
        activity=[("Zambia Green Energy","Updated business profile","12m ago"),("Sunrise Agro Ltd","Posted new opportunity","28m ago"),("Invest Zambia Fund","Viewed project","1h ago"),("Copperbelt Traders","Sent you a message","2h ago"),("GreenTech Solutions","Investor interest received","4h ago")]
        for n,d,t in activity:
            f=tk.Frame(left,bg="white"); f.pack(fill="x",padx=12,pady=3); tk.Label(f,text=n,bg="white",fg="#1f3b32",font=("Segoe UI",9,"bold")).pack(side="left"); tk.Label(f,text=t,bg="white",fg="#71818a",font=("Segoe UI",8)).pack(side="left",padx=8); tk.Label(f,text=t,bg="white",fg="#8a989f",font=("Segoe UI",8)).pack(side="right")

        mid=tk.Frame(content,bg="white",highlightbackground="#d8e5df",highlightthickness=1); mid.grid(row=3,column=2,sticky="nsew",padx=4,pady=4)
        tk.Label(mid,text="Top Opportunities",bg="white",fg="#20313b",font=("Segoe UI",11,"bold")).pack(anchor="w",padx=12,pady=8)
        for r in self.query("SELECT title,location,value FROM opportunities ORDER BY id DESC LIMIT 5"):
            tk.Label(mid,text=f"{r['title']}",bg="white",fg="#155e45",font=("Segoe UI",9,"bold"),anchor="w").pack(fill="x",padx=12,pady=(4,0)); tk.Label(mid,text=f"{r['location']}   •   {r['value']}",bg="white",fg="#74848a",font=("Segoe UI",8),anchor="w").pack(fill="x",padx=12)

        right=tk.Frame(content,bg="white",highlightbackground="#d8e5df",highlightthickness=1); right.grid(row=3,column=3,sticky="nsew",padx=4,pady=4)
        tk.Label(right,text="Notifications & Intelligence",bg="white",fg="#20313b",font=("Segoe UI",11,"bold")).pack(anchor="w",padx=12,pady=8)
        for text in ["New message from Zambia Green Energy","Investor matched to your project","New opportunity posted","Marketplace order update","System backup completed"]:
            tk.Label(right,text="●  "+text,bg="white",fg="#40545d",font=("Segoe UI",8),anchor="w",wraplength=280).pack(fill="x",padx=12,pady=5)
        tk.Label(right,text="Key sectors",bg="white",fg="#20313b",font=("Segoe UI",9,"bold")).pack(anchor="w",padx=12,pady=(12,4))
        for sector,pct in [("Mining",28),("Agriculture",22),("Manufacturing",18),("Energy",12),("Construction",10)]:
            tk.Label(right,text=f"{sector:<16} {pct}%",bg="white",fg="#587078",font=("Consolas",8),anchor="w").pack(fill="x",padx=12,pady=2)

        tk.Label(self.main,text="GEMA v1.0  •  Zambia Open Marketplace & Industrial Intelligence Platform  •  Connect • Match • Invest • Grow",bg="#eaf3ef",fg="#567068",font=("Segoe UI",8)).pack(fill="x",side="bottom",pady=(4,0))
    def treepage(self,title,sub,table,cols,rows,buttons=None):
        self.clear();self.head(title,sub)
        if buttons:
            bar=tk.Frame(self.main,bg="#f5f7fb");bar.pack(fill="x",padx=28)
            for txt,cmd in buttons:ttk.Button(bar,text=txt,command=cmd).pack(side="left",padx=(0,7))
        tr=ttk.Treeview(self.main,columns=cols,show="headings")
        for c in cols:tr.heading(c,text=c.title());tr.column(c,width=max(120,1100//len(cols)))
        tr.pack(fill="both",expand=True,padx=28,pady=18)
        for r in rows:tr.insert("", "end",values=tuple(r[c] for c in cols))
        return tr
    def page_people(self):
        rows=self.query("SELECT * FROM users ORDER BY id DESC")
        self.treepage("People & Organisations","Parties participating in GEMA", "users",
                      ["name","role","organisation","email"],rows,
                      [("Add Party",self.add_party)])
    def add_party(self):
        w=self.form("Add Party",[("Name",""),("Role","Business / Investor / Institution / User"),("Organisation",""),("Email","")])
        def go(es):
            self.exec("INSERT INTO users(name,role,organisation,email) VALUES(?,?,?,?)",[e.get() for e in es]);w.destroy();self.page_people()
        ttk.Button(w,text="Save",command=lambda:go(es)).pack(pady=18)
    def form(self,title,fields):
        w=tk.Toplevel(self);w.title(title);w.geometry("520x450");es=[]
        for lab,ph in fields:
            tk.Label(w,text=lab).pack(anchor="w",padx=20,pady=(13,2));e=tk.Entry(w);e.pack(fill="x",padx=20);es.append(e)
        return w
    def page_businesses(self):
        rows=self.query("SELECT * FROM businesses ORDER BY id DESC")
        self.treepage("Business Directory","Business profiles and capabilities", "businesses",
                      ["name","sector","location","status"],rows,[("Register Business",self.add_business)])
    def add_business(self):
        w=self.form("Register Business",[("Business name",""),("Sector",""),("Location",""),("Description","")])
        def go(es):
            self.exec("INSERT INTO businesses(name,sector,location,description,owner_id,status) VALUES(?,?,?,?,?,?)",
                      [es[0].get(),es[1].get(),es[2].get(),es[3].get(),1,"User-created"]);w.destroy();self.page_businesses()
        ttk.Button(w,text="Save Business",command=lambda:go(es)).pack(pady=18)
    def page_marketplace(self):
        rows=self.query("SELECT * FROM marketplace ORDER BY id DESC")
        self.treepage("Marketplace","Products, services and opportunities", "marketplace",
                      ["title","kind","sector","location","status"],rows,[("Publish Listing",self.add_listing)])
    def add_listing(self):
        w=self.form("Publish Marketplace Listing",[("Title",""),("Type","Product / Service / Opportunity"),("Sector",""),("Location",""),("Description","")])
        def go(es):
            self.exec("INSERT INTO marketplace(title,kind,sector,location,description,owner_id,status) VALUES(?,?,?,?,?,?,?)",
                      [es[0].get(),es[1].get(),es[2].get(),es[3].get(),es[4].get(),1,"Published"]);w.destroy();self.page_marketplace()
        ttk.Button(w,text="Publish",command=lambda:go(es)).pack(pady=18)
    def page_industrial(self):
        self.clear();self.head("Industrial Intelligence","Sector intelligence, value addition and industrial opportunity discovery")
        for s in ["Agriculture & Food Processing","Mining & Mineral Value Addition","Manufacturing","Energy & Utilities","Logistics & Infrastructure","ICT & Digital Services"]:
            f=tk.Frame(self.main,bg="white",highlightbackground="#dbe3ef",highlightthickness=1);f.pack(fill="x",padx=28,pady=5)
            tk.Label(f,text=s,font=("Segoe UI",12,"bold"),bg="white").pack(side="left",padx=15,pady=14)
            ttk.Button(f,text="Explore",command=lambda z=s:self.explore_sector(z)).pack(side="right",padx=15)
    def explore_sector(self,s):
        rows=self.query("SELECT * FROM opportunities WHERE sector LIKE ?",("%"+s.split(" & ")[0]+"%",))
        messagebox.showinfo("Industrial Intelligence",f"{s}\n\n{len(rows)} matching opportunity records found in the local database.")
    def page_opportunities(self):
        rows=self.query("SELECT * FROM opportunities ORDER BY id DESC")
        self.treepage("Industrial Opportunities","Open opportunities from the GEMA opportunity layer","opportunities",
                      ["title","sector","location","stage","value","status"],rows,[("Add Opportunity",self.add_opportunity)])
    def add_opportunity(self):
        w=self.form("Add Opportunity",[("Title",""),("Sector",""),("Location",""),("Stage",""),("Value",""),("Description","")])
        def go(es):
            self.exec("INSERT INTO opportunities(title,sector,location,stage,value,description,status) VALUES(?,?,?,?,?,?,?)",
                      [x.get() for x in es]+["Open"]);w.destroy();self.page_opportunities()
        ttk.Button(w,text="Save Opportunity",command=lambda:go(es)).pack(pady=18)
    def page_projects(self):
        rows=self.query("SELECT * FROM projects ORDER BY id DESC")
        self.treepage("Investment Projects","Feasibility, pipeline and funding requirements","projects",
                      ["name","sector","location","stage","funding"],rows,[("Create Project",self.add_project)])
    def add_project(self):
        w=self.form("Create Investment Project",[("Project name",""),("Sector",""),("Location",""),("Stage",""),("Funding",""),("Description","")])
        def go(es):
            self.exec("INSERT INTO projects(name,sector,location,stage,funding,description,owner_id) VALUES(?,?,?,?,?,?,?)",
                      [x.get() for x in es]+[1]);w.destroy();self.page_projects()
        ttk.Button(w,text="Create",command=lambda:go(es)).pack(pady=18)
    def page_investors(self):
        rows=self.query("SELECT * FROM investors ORDER BY id DESC")
        self.treepage("Investors","Investor profiles and investment capabilities","investors",
                      ["name","focus","geography","ticket","status"],rows,[("Add Investor",self.add_investor)])
    def add_investor(self):
        w=self.form("Add Investor",[("Name",""),("Focus sectors",""),("Geography",""),("Ticket range",""),("Capabilities","")])
        def go(es):
            self.exec("INSERT INTO investors(name,focus,geography,ticket,capabilities,status) VALUES(?,?,?,?,?,?)",
                      [x.get() for x in es]+["Active"]);w.destroy();self.page_investors()
        ttk.Button(w,text="Save Investor",command=lambda:go(es)).pack(pady=18)
    def page_matching(self):
        self.clear();self.head("Investor Matching","Run an explainable match and store the result")
        projects=self.query("SELECT id,name,sector FROM projects")
        investors=self.query("SELECT id,name,focus FROM investors")
        tk.Label(self.main,text="Project",bg="#f5f7fb").pack(anchor="w",padx=28);pc=ttk.Combobox(self.main,state="readonly",width=70,
            values=[f"{p['id']} — {p['name']}" for p in projects]);pc.pack(anchor="w",padx=28,pady=5)
        tk.Label(self.main,text="Investor",bg="#f5f7fb").pack(anchor="w",padx=28);ic=ttk.Combobox(self.main,state="readonly",width=70,
            values=[f"{i['id']} — {i['name']}" for i in investors]);ic.pack(anchor="w",padx=28,pady=5)
        out=tk.Text(self.main,height=18);out.pack(fill="both",expand=True,padx=28,pady=15)
        def run():
            if not pc.get() or not ic.get():return
            pid=int(pc.get().split(" — ")[0]);iid=int(ic.get().split(" — ")[0])
            p=self.query("SELECT * FROM projects WHERE id=?",(pid,))[0];inv=self.query("SELECT * FROM investors WHERE id=?",(iid,))[0]
            sector=20 if any(x.strip().lower() in inv["focus"].lower() for x in p["sector"].split(",")) or p["sector"].lower() in inv["focus"].lower() else 8
            geo=20 if "zambia" in inv["geography"].lower() else 10
            score=min(98,sector+geo+25+20+10)
            factors=["Sector alignment" if sector==20 else "Partial sector alignment","Geography alignment" if geo==20 else "Regional geography",
                     "Funding/ticket compatibility (demo signal)","Industrial capability fit (demo signal)","Profile completeness"]
            self.exec("INSERT INTO matches(project_id,investor_id,score,factors,status) VALUES(?,?,?,?,?)",(pid,iid,score,json.dumps(factors),"Suggested"))
            self.exec("INSERT INTO notifications(recipient,message,created_at) VALUES(?,?,datetime('now'))",(inv["name"],f"New GEMA project match suggestion: {p['name']}"))
            out.delete("1.0","end");out.insert("end",json.dumps({"project":p["name"],"investor":inv["name"],"score":score,"factors":factors},indent=2))
        ttk.Button(self.main,text="Run Explainable Match",command=run).pack(anchor="w",padx=28)
    def page_workflow(self):
        self.clear();self.head("Deal Workflow","Move a selected project through the investment lifecycle")
        ps=self.query("SELECT id,name FROM projects");pc=ttk.Combobox(self.main,state="readonly",width=70,values=[f"{p['id']} — {p['name']}" for p in ps]);pc.pack(anchor="w",padx=28)
        stages=["Due Diligence","Secure Data Room","Term Sheet & Negotiation","Closing Readiness","Monitoring"]
        for s in stages:
            f=tk.Frame(self.main,bg="white",highlightbackground="#dbe3ef",highlightthickness=1);f.pack(fill="x",padx=28,pady=5)
            tk.Label(f,text=s,font=("Segoe UI",11,"bold"),bg="white").pack(side="left",padx=15,pady=12)
            ttk.Button(f,text="Advance / Open",command=lambda z=s:self.advance_workflow(pc,z)).pack(side="right",padx=15)
    def advance_workflow(self,pc,stage):
        if not pc.get():messagebox.showwarning("GEMA","Select a project first.");return
        pid=int(pc.get().split(" — ")[0]);self.exec("INSERT INTO workflow(project_id,stage,status,notes) VALUES(?,?,?,?)",(pid,stage,"Active","Test workflow event"))
        self.exec("INSERT INTO notifications(recipient,message,created_at) VALUES(?,?,datetime('now'))",("George Phiri",f"Workflow advanced: {stage}"))
        messagebox.showinfo("GEMA Workflow",f"{stage} recorded for the selected project.")
    def page_profile(self):
        self.clear(); self.head("My Profile","Your GEMA identity and operating profile")
        u=self.query("SELECT * FROM users WHERE name=?",(self.current_user,))[0]
        f=tk.Frame(self.main,bg="white",highlightbackground="#d8e5df",highlightthickness=1); f.pack(fill="x",padx=28,pady=10)
        for lab,val in [("Name",u["name"]),("Role",u["role"]),("Organisation",u["organisation"]),("Email",u["email"])]:
            tk.Label(f,text=lab,bg="white",fg="#71818a",font=("Segoe UI",9,"bold")).pack(anchor="w",padx=18,pady=(12,0)); tk.Label(f,text=val,bg="white",fg="#1f3b32",font=("Segoe UI",11)).pack(anchor="w",padx=18,pady=(0,8))
        tk.Label(self.main,text="Profile information feeds GEMA discovery and explainable matching in this local development build.",bg="#f3f7f5",fg="#60737b").pack(anchor="w",padx=28,pady=10)
    def page_duediligence(self):
        self.clear(); self.head("Due Diligence","Track project verification before investment decisions")
        for p in self.query("SELECT id,name,stage FROM projects"):
            f=tk.Frame(self.main,bg="white",highlightbackground="#d8e5df",highlightthickness=1); f.pack(fill="x",padx=28,pady=5)
            tk.Label(f,text=p["name"],bg="white",fg="#164e3b",font=("Segoe UI",11,"bold")).pack(side="left",padx=15,pady=12); tk.Label(f,text=f"Stage: {p['stage']}",bg="white",fg="#71818a").pack(side="left"); ttk.Button(f,text="Open Checklist",command=lambda x=p:self.due_checklist(x)).pack(side="right",padx=15)
    def due_checklist(self,p):
        items=["Corporate identity","Ownership / beneficial ownership","Financial information","Project feasibility","Permits / regulatory","Commercial contracts","Risk review"]
        w=tk.Toplevel(self); w.title("Due Diligence — "+p["name"]); w.geometry("560x480"); tk.Label(w,text=p["name"],font=("Segoe UI",16,"bold")).pack(anchor="w",padx=20,pady=15)
        for item in items: tk.Checkbutton(w,text=item,anchor="w").pack(fill="x",padx=25,pady=4)
        ttk.Button(w,text="Save Review",command=w.destroy).pack(pady=18)
    def page_dataroom(self):
        self.clear(); self.head("Data Room","Secure-document workspace for investment due diligence")
        tk.Label(self.main,text="Development workspace — document upload/storage is represented by workflow records in this test build.",bg="#f3f7f5",fg="#60737b").pack(anchor="w",padx=28,pady=8)
        for p in self.query("SELECT id,name FROM projects"):
            f=tk.Frame(self.main,bg="white",highlightbackground="#d8e5df",highlightthickness=1); f.pack(fill="x",padx=28,pady=5); tk.Label(f,text=p["name"],bg="white",font=("Segoe UI",10,"bold")).pack(side="left",padx=15,pady=12); ttk.Button(f,text="Open Data Room",command=lambda x=p:self.dataroom_notice(x)).pack(side="right",padx=15)
    def dataroom_notice(self,p):
        messagebox.showinfo("GEMA Data Room", f"Data Room opened for {p['name']}.\n\nProduction version: encrypted object storage, access permissions and audit logging.")
    def page_messages(self):
        rows=self.query("SELECT * FROM messages ORDER BY id DESC")
        self.treepage("Messages","Party-to-party communication test","messages",
                      ["sender","recipient","subject","status","created_at"],rows,[("New Message",self.new_message)])
    def new_message(self):
        w=self.form("New GEMA Message",[("Recipient",""),("Subject",""),("Message","")])
        def go(es):
            self.exec("INSERT INTO messages(sender,recipient,subject,body,status,created_at) VALUES(?,?,?,?,?,datetime('now'))",
                      ("George Phiri",es[0].get(),es[1].get(),es[2].get(),"Sent"))
            self.exec("INSERT INTO notifications(recipient,message,created_at) VALUES(?,?,datetime('now'))",(es[0].get(),f"New message: {es[1].get()}"))
            w.destroy();self.page_messages()
        ttk.Button(w,text="Send",command=lambda:go(es)).pack(pady=18)
    def page_notifications(self):
        rows=self.query("SELECT * FROM notifications ORDER BY id DESC")
        self.treepage("Notifications","System and party workflow notifications","notifications",
                      ["recipient","message","read_flag","created_at"],rows,[("Mark All Read",self.read_all)])
    def read_all(self):
        self.exec("UPDATE notifications SET read_flag=1");self.page_notifications()
    def page_analytics(self):
        self.clear();self.head("Analytics","Live counts from the GEMA SQLite database")
        for t in ["users","businesses","marketplace","opportunities","projects","investors","matches","workflow","messages","notifications"]:
            n=self.query(f"SELECT COUNT(*) n FROM {t}")[0]["n"]
            tk.Label(self.main,text=f"{t.title()}: {n}",font=("Segoe UI",12),bg="#f5f7fb").pack(anchor="w",padx=45,pady=4)
    def page_admin(self):
        self.clear();self.head("Administration","Local development controls")
        ttk.Button(self.main,text="Reset Test Database",command=self.reset_db).pack(anchor="w",padx=28,pady=10)
        tk.Label(self.main,text="Database file: gema.db\nThis is a development build. Production authentication, encryption, cloud hosting, audit controls and real integrations still need to be implemented.",
                 bg="#f5f7fb",fg="#64748b",justify="left").pack(anchor="w",padx=28,pady=20)
    def reset_db(self):
        if messagebox.askyesno("Reset","Delete local test data and restore the seeded GEMA demo?"):
            self.destroy()
            os.remove(DB) if os.path.exists(DB) else None
            init();GEMA().mainloop()
    def global_search(self):
        q=self.search.get().strip()
        self.clear();self.head("Global Search",f"Results for: {q or 'all'}")
        if not q:q="%"
        else:q="%"+q+"%"
        groups=[
          ("Businesses","SELECT name,sector,location FROM businesses WHERE name LIKE ? OR sector LIKE ? OR location LIKE ?",[q,q,q]),
          ("Marketplace","SELECT title,kind,location FROM marketplace WHERE title LIKE ? OR sector LIKE ? OR location LIKE ?",[q,q,q]),
          ("Opportunities","SELECT title,sector,location FROM opportunities WHERE title LIKE ? OR sector LIKE ? OR location LIKE ?",[q,q,q]),
          ("Projects","SELECT name,sector,location FROM projects WHERE name LIKE ? OR sector LIKE ? OR location LIKE ?",[q,q,q]),
          ("Investors","SELECT name,focus,geography FROM investors WHERE name LIKE ? OR focus LIKE ? OR geography LIKE ?",[q,q,q])]
        found=0
        for name,sql,args in groups:
            rs=self.query(sql,args)
            if rs:
                found+=len(rs);tk.Label(self.main,text=name,font=("Segoe UI",14,"bold"),bg="#f5f7fb").pack(anchor="w",padx=28,pady=(12,4))
                for r in rs:tk.Label(self.main,text=" • "+" | ".join(str(v) for v in r),bg="#f5f7fb",font=("Segoe UI",10)).pack(anchor="w",padx=42,pady=2)
        if not found:tk.Label(self.main,text="No results found.",bg="#f5f7fb",fg="#64748b").pack(anchor="w",padx=28,pady=20)

if __name__=="__main__":
    GEMA().mainloop()
