@echo off
title GEMA Full Python Test
py "%~dp0gema.py"
if errorlevel 1 python "%~dp0gema.py"
if errorlevel 1 (
 echo.
 echo Python was not found. Install Python 3, then run this file again.
 echo https://www.python.org/downloads/
 pause
)
