GEMA — COMPACT COMPLETE VISION PYTHON BUILD

This build keeps the interactive SQLite-based GEMA development workflow and implements the new compact desktop workspace using the supplied GEMA visual direction.

RUN:
1. Install Python 3 on Windows.
2. Double-click RUN_GEMA.bat or run: python gema.py

Included:
- Compact branded desktop dashboard
- GEMA banner background
- Global search
- My Profile
- People & Organisations
- Business Directory
- Marketplace
- Industrial Intelligence
- Opportunities
- Investment Projects
- Investors
- Explainable Investor Matching
- Deal Workflow
- Due Diligence checklist
- Data Room workspace
- Messages and notifications
- Analytics
- Administration
- Local SQLite persistence

IMPORTANT: This is a functional development/test build, not a production deployment. Production authentication, cloud database, encrypted document storage, audit controls, real external integrations and deployment still need to be implemented.
